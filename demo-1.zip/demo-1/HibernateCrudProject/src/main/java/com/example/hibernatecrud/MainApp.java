package com.example.hibernatecrud;

import com.example.hibernatecrud.entity.Country;
import com.example.hibernatecrud.entity.Region;
import com.example.hibernatecrud.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class MainApp {

    public static void main(String[] args) {

        // INSERT
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();

            Region region = new Region("Asia");
           
            session.save(region);

            Country country = new Country("IN", "India", region);
            
            session.save(country);

            tx.commit();
           
            System.out.println("✅ Inserted successfully.");
        }

        // READ
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Country country = session.get(Country.class, "IN");
            System.out.println("🔍 Fetched country: " + country);
        }

        // UPDATE
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            
             Transaction tx = session.beginTransaction();

            Country country = session.get(Country.class, "IN");
            if (country != null) {
                country.setCountryName("Bharat");
                session.update(country);
                tx.commit();
                System.out.println("✏️ Updated successfully.");
            }
        }

        // DELETE
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();

            Country country = session.get(Country.class, "IN");
            if (country != null) {
                session.delete(country);
                tx.commit();
                System.out.println("🗑️ Deleted successfully.");
            }
        }

        HibernateUtil.getSessionFactory().close();
    }
}
