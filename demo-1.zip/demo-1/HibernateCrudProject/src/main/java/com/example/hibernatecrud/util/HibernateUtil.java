package com.example.hibernatecrud.util;

import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;

import com.example.hibernatecrud.entity.Region;

import com.example.hibernatecrud.entity.Country;

public class HibernateUtil {
    private static SessionFactory sessionFactory;

    static {
        
      try {
            Configuration config = new Configuration();
            config.configure("hibernate.cfg.xml");

            // Add annotated classes
            config.addAnnotatedClass(Region.class);
            config.addAnnotatedClass(Country.class);

            sessionFactory = config.buildSessionFactory();
        } 
        catch (Throwable ex) {
           
            System.err.println("SessionFactory creation failed: " + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        getSessionFactory().close();
    }
}
