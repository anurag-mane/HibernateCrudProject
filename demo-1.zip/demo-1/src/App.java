import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class App {
    public static void main(String[] args) {
        String url="jdbc:postgresql://localhost:5432/mydb";
        String user="postgres";
        String password="@anurag__mane46";

        try {
            Class.forName("org.postgresql.Driver");
            Connection conn=DriverManager.getConnection(url,user,password);
            if(conn!=null) {
                System.out.println("connected to the database");
            }
        }  catch(SQLException e) {
            System.out.println("connection failed" +e.getMessage());
        }  catch(ClassNotFoundException e) {
            System.out.println("postgresql driver not found "+ e.getMessage());
        }

    }
}
